package com.ty.Auction.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.Auction.entity.Product;
import com.ty.Auction.repository.ProductRepository;
import com.ty.Auction.repository.uploadRepository;

@Service
public class productService {

    @Autowired
    private ProductRepository productRepository;

    private uploadRepository uploadrepository;
    
    public interface ProductService {
        Product getProductById(Long id);
    }

    
    public Product saveProduct(Product product) {
    	System.out.print(product);
        return productRepository.save(product);
    }
    public void saveEntity(Product product) {
        uploadrepository.save(product);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
  }
