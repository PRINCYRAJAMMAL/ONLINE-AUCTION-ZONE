package com.ty.Auction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.Auction.entity.Seller;

public interface sellerRepository extends JpaRepository<Seller, Long> {
    boolean existsByName(String name);
    Seller findByName(String name);
}

