package com.ty.Auction.entity;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    private String username;
    private String password;
    private String email;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Long id, String username, String password, String email) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.email = email;
	}
	@Override
	public String toString() {
		return "User [ username=" + username + ", password=" + password + ", email=" + email + "]";
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	 @GetMapping("/auction")
	    public String auctionPage(Model model) {
	        model.addAttribute("auctionItems", AuctionItem.findAll());
	        return "auction";
	    }

	    @PostMapping("/auction")
	    public String addAuctionItem(@RequestParam("image") MultipartFile image,
	                                 @RequestParam("price") Double price,
	                                 @RequestParam("details") String details,
	                                 @RequestParam("biddingEndTime") String biddingEndTime) throws IOException {
	        // Save image to a directory
	        String imagePath = "images/" + image.getOriginalFilename();
	        File imageFile = new File(imagePath);
	        image.transferTo(imageFile);

	        // Save auction item
	        AuctionItem auctionItem = new AuctionItem(id, imagePath, imagePath, null, price, null, null);
	        auctionItem.setImageUrl(imagePath);
	        auctionItem.setPrice(price);
	        auctionItem.setDetails(details);
	        auctionItem.setBiddingEndTime(LocalDateTime.parse(biddingEndTime));
	        AuctionItem.save(auctionItem);

	        return "redirect:/auction";
	    }
	}
   



