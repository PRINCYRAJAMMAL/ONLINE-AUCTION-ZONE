package com.ty.Auction.Controller;

import com.ty.Auction.entity.Bid;
import com.ty.Auction.entity.Product;
import com.ty.Auction.entity.Seller;
import com.ty.Auction.entity.User;
import com.ty.Auction.Service.BidService;
import com.ty.Auction.Service.UserService;
import com.ty.Auction.repository.uploadRepository;
import com.ty.Auction.repository.ProductRepository.ProductService;

import jakarta.servlet.http.HttpSession;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class HomeController {

    private final UserService userService;
    private final BidService bidService;
    private final uploadRepository uploadRepo;
    private final ProductService productService;

    public HomeController(UserService userService, BidService bidService, uploadRepository uploadRepo, ProductService productService) {
        this.userService = userService;
        this.bidService = bidService;
        this.uploadRepo = uploadRepo;
        this.productService = productService;
    }

    @GetMapping("/index")
    public String index() {
        return "index";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String username,
                            @RequestParam String password,
                            Model model,
                            RedirectAttributes redirectAttributes) {
        if (userService.authenticate(username, password)) {
            redirectAttributes.addFlashAttribute("username", username);
            return "redirect:/home";
        } else {
            model.addAttribute("error", "Invalid username or password.");
            return "login";
        }
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@RequestParam String username,
                               @RequestParam String password,
                               @RequestParam String email,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        if (userService.usernameExists(username)) {
            model.addAttribute("error", "Username already exists.");
            return "register"; // Return to register page with error message
        }

        // Create a new user object and save it
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        
        userService.saveUser(user);

        // Redirect to login page with success message
        redirectAttributes.addFlashAttribute("message", "Successfully registered! Please login.");
        return "redirect:/login";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/product")
    public String Product(Model model) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "Product";  // Ensure viewProducts.html exists in src/main/resources/templates
    }
    
    @GetMapping("/sellerregister")
    public String sellerRegisterForm(Model model) {
        model.addAttribute("seller", new Seller()); // Add empty seller object to model
        return "sellerregister";
    }

    @PostMapping("/sellerregister")
    public String registerSeller(@ModelAttribute("seller") Seller seller,
                                 @RequestParam String name,
                                 @RequestParam String password,
                                 @RequestParam String email,
                                 Model model,
                                 RedirectAttributes redirectAttributes) {
        if (userService.usernameExists(name)) {
            model.addAttribute("error", "Username already exists.");
            return "sellerregister"; 
        }

        // Populate the seller object
        seller.setName(name);
        seller.setPassword(password);
        seller.setEmail(email);
        
        userService.saveSeller(seller);

        redirectAttributes.addFlashAttribute("message", "Successfully registered! Please login.");
        return "redirect:/sellerlogin";
    }

    @GetMapping("/sellerlogin")
    public String showLoginPage(Model model) {
        return "sellerlogin";
    }

    @PostMapping("/sellerlogin")
    public String handleLogin(@RequestParam String name,
                              @RequestParam String password,
                              Model model,
                              RedirectAttributes redirectAttributes) {
        if (userService.authenticate(name, password)) {
            redirectAttributes.addFlashAttribute("name", name);
            return "redirect:/sellerhome";
        } else {
            model.addAttribute("error", "Invalid username or password.");
            return "sellerlogin";
        }
    }

    @GetMapping("/sellerhome")
    public String sellerHome(Model model) {
        return "sellerhome";
    }

    @GetMapping("/addProduct")
    public String showAddProductForm(Model model) {
        model.addAttribute("products", new Product());
        return "addProduct"; // Ensure this matches the template name
    }
    
    @PostMapping("/addProduct")
    public String addProduct(@RequestParam String category,
                             @RequestParam("product_name") String product_name,
                             @RequestParam("description") String description,
                             @RequestParam("price") double price,
                             @RequestParam("start_time") LocalDateTime startTime,
                             @RequestParam("end_time") LocalDateTime endTime,
                             @RequestParam MultipartFile image,
                             HttpSession session) {
        if (description == null || description.isEmpty() ||
            price <= 0 ||
            startTime == null ||
            endTime == null ||
            image.isEmpty()) {
            session.setAttribute("msg", "Please fill all required fields.");
            return "redirect:/addProduct";
        }

        Product product = new Product();
        product.setProduct_name(product_name);
        product.setDescription(description);
        product.setPrice(price);
        product.setStart_time(startTime);
        product.setEnd_time(endTime);
        product.setImage(image.getOriginalFilename());
        product.setCategory(category);

        // Save the product
        uploadRepo.save(product);

        // Save the image
        try {
            File saveFile = new ClassPathResource("static/images").getFile();
            Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + image.getOriginalFilename());
            Files.copy(image.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
            session.setAttribute("msg", "Image upload failed.");
            return "redirect:/addProduct";
        }

        session.setAttribute("msg", "Product added successfully.");
        return "redirect:/products";
    }

    @GetMapping("/products")
    public String viewProduct(Model model) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "viewProducts";  // Ensure viewProducts.html exists in src/main/resources/templates
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Product product = productService.getProductById(id);
        model.addAttribute("product", product);
        return "edit-product"; // This should match the HTML file name
    }

    @PostMapping("/update")
    public String updateProduct(@RequestParam("id") Long id,
                                @RequestParam("product_name") String product_name,
                                @RequestParam("category") String category,
                                @RequestParam("price") Double price,
                                @RequestParam("start_time") LocalDateTime startTime,
                                @RequestParam("end_time") LocalDateTime endTime,
                                @RequestParam("description") String description,
                                @RequestParam("image") MultipartFile imageFile,
                                RedirectAttributes redirectAttributes) {
        try {
            Product product = productService.getProductById(id);

            product.setProduct_name(product_name);
            product.setCategory(category);
            product.setPrice(price);
            product.setStart_time(startTime);
            product.setEnd_time(endTime);
            product.setDescription(description);

            if (!imageFile.isEmpty()) {
                String imageName = imageFile.getOriginalFilename();
                String imagePath = "path/to/img/" + imageName; // Update this path as necessary
                imageFile.transferTo(new File(imagePath));
                product.setImage(imageName);
            }

            productService.saveProduct(product);
            redirectAttributes.addFlashAttribute("message", "Product updated successfully!");
            return "redirect:/products";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update product!");
            return "redirect:/products";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") Long id) {
        productService.deleteProduct(id);
        return "redirect:/products";
    }

    @GetMapping("/bid/{id}")
    public String getBidPage(@PathVariable Long id, Model model) {
        List<Bid> bids = bidService.getBidById(id);
        model.addAttribute("bids", bids);
        return "auction";
    }

    @PostMapping("/acceptBid")
    public String acceptBid(@RequestParam("bidId") Long bidId) {
        bidService.acceptBid(bidId);
        return "redirect:/sellerBiddingPage";
    }

    @PostMapping("/rejectBid")
    public String rejectBid(@RequestParam("bidId") Long bidId) {
        bidService.rejectBid(bidId);
        return "redirect:/sellerBiddingPage";
    }
}
