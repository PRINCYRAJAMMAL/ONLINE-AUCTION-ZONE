package com.ty.Auction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.Auction.entity.Product;

public interface uploadRepository extends JpaRepository<Product,Integer> {
	

}