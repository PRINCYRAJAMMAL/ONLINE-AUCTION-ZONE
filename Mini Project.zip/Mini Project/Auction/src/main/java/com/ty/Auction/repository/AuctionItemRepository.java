package com.ty.Auction.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.Auction.entity.AuctionItem;

public interface AuctionItemRepository extends JpaRepository<AuctionItem, Long> {
}

