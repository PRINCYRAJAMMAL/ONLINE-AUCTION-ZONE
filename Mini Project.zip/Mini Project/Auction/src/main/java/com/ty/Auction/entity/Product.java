package com.ty.Auction.entity;

import java.time.LocalDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "products")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_name", nullable = false)
    private String product_name;

    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "price", nullable = false)
    private double price;

    @Column(name = "start_time", nullable = false)
    private LocalDateTime start_time;

    @Column(name = "end_time", nullable = false)
    private LocalDateTime end_time;
    
    @Column(name = "description", nullable = false)
    private String description;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(Long id, String product_name, String category, double price, LocalDateTime start_time,
			LocalDateTime end_time, String description) {
		super();
		this.id = id;
		this.product_name = product_name;
		this.category = category;
		this.price = price;
		this.start_time = start_time;
		this.end_time = end_time;
		this.description = description;
	}

	@Override
	public String toString() {
		return "Product [product_name=" + product_name + ", category=" + category + ", price=" + price
				+ ", start_time=" + start_time + ", end_time=" + end_time + ", description=" + description + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDateTime getStart_time() {
		return start_time;
	}

	public void setStart_time(LocalDateTime start_time) {
		this.start_time = start_time;
	}

	public LocalDateTime getEnd_time() {
		return end_time;
	}

	public void setEnd_time(LocalDateTime end_time) {
		this.end_time = end_time;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setImage(String originalFilename) {
		// TODO Auto-generated method stub
		
	}

	
	
    
}


	