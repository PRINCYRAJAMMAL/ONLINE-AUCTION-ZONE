package com.ty.Auction.repository;

import com.ty.Auction.entity.AuctionItem;
import com.ty.Auction.entity.Seller;
import com.ty.Auction.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
	Seller save(Seller seller); // For saving Seller entity
   
    User findByUsername(String username);
    @Query("SELECT ai FROM AuctionItem ai")
    List<AuctionItem> findAllAuctionItems();

	void save(AuctionItem auctionItem);
}
