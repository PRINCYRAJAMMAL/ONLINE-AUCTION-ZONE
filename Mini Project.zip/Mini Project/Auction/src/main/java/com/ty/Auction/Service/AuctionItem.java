package com.ty.Auction.Service;

public class AuctionItem {

}
