package com.ty.Auction.Service;



import com.ty.Auction.entity.AuctionItem;
import com.ty.Auction.entity.Seller;
import com.ty.Auction.entity.User;
import com.ty.Auction.repository.UserRepository;
import com.ty.Auction.repository.sellerRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    private final sellerRepository sellerRepository;

    public UserService(sellerRepository sellerRepository) {
        this.sellerRepository = sellerRepository;
    }

    public boolean usernameExists1(String username) {
        return sellerRepository.existsByName(username);
    }

    public boolean authenticate(String username, String password) {
        Seller seller = sellerRepository.findByName(username);
        System.out.print(seller);
        return seller != null && seller.getPassword().equals(password);
    }

    public boolean usernameExists(String username) {
        return userRepository.findByUsername(username) != null;
    }

    public void saveUser(User user) {
        userRepository.save(user);
    }

    public void saveAuctionItem(AuctionItem auctionItem) {
        userRepository.save(auctionItem);
    }

    public List<AuctionItem> findAllAuctionItems() {
        return userRepository.findAllAuctionItems();
    }

	public void saveSeller(Seller seller) {
	        userRepository.save(seller);
	    }
	public boolean authenticate1(String name, String password) {
        Seller seller = sellerRepository.findByName(name);
        return seller != null && seller.getPassword().equals(password);
    }

	public Object getCurrentUser() {
		// TODO Auto-generated method stub
		return null;
	}

	

	}
