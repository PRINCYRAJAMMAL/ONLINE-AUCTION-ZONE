package com.ty.Auction.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.Auction.entity.Bid;
import com.ty.Auction.repository.BidRepository;

@Service
public class BidService {
    @SuppressWarnings("unused")
	@Autowired
    private BidRepository BidRepository;

   

	public List<Bid> getBidById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}



	  private BidRepository bidRepository;

	    public void saveBid(Long productId, int amount, String bidder) {
	        Bid bid = new Bid();
	        Long Id = null;
			bid.setId(Id);
	        bid.setAmount(amount);
	        bid.setBidder(bidder);
	        bid.setTimestamp(LocalDateTime.now());
	        bid.setStatus("Pending");
	        System.out.println(bid);
	        bidRepository.save(bid);
	    }

	    public void acceptBid(Long bidId) {
	        Bid bid = bidRepository.findById(bidId).orElseThrow(() -> new IllegalArgumentException("Invalid bid Id:" + bidId));
	        bid.setStatus("Accepted");
	        bidRepository.save(bid);
	    }

	    public void rejectBid(Long bidId) {
	        Bid bid = bidRepository.findById(bidId).orElseThrow(() -> new IllegalArgumentException("Invalid bid Id:" + bidId));
	        bid.setStatus("Rejected");
	        bidRepository.save(bid);
	    }


	    public String processBid(Long id, double amount) {
	        boolean isAccepted = checkIfBidAccepted(id, amount);
	        if (amount>=300) {
	            Bid bid = new Bid();
	            bid.setId(id);
	            bid.setAmount(amount);
	            bidRepository.save(bid);
	            return "Accepted";
	        } else {
	            return "Rejected";
	        }
	    }

	    private boolean checkIfBidAccepted(Long id, double amount) {
	        return amount > getCurrentHighestBid(id);
	    }
	    private double getCurrentHighestBid(Long id) {
	        Optional<Bid> bids = bidRepository.findById(id);
	        return bids.stream()
	                .mapToDouble(Bid::getAmount)
	                .max()
	                .orElse(0.0);
	    }
	
}
