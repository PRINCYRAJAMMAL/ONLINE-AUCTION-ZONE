package com.ty.Auction.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;

@Entity
public class AuctionItem {
    @Override
	public String toString() {
		return "AuctionItem [ imageUrl=" + imageUrl + ", price=" + price + ", details=" + details
				+ ", product=" + product + ", user=" + user + ", seller=" + seller + "]";
	}

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String imageUrl;
    private Double price;
    private String details;
    
    @ManyToOne
    @JoinColumn(name = "product_id", referencedColumnName = "id", nullable = false)
    private Product product;  // Foreign key reference to Product

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false)
    private User user;  // Foreign key reference to User

    @ManyToOne
    @JoinColumn(name = "seller_id", referencedColumnName = "id", nullable = false)
    private Seller seller;  // Foreign key reference to Seller

	public AuctionItem(Long id, String imageUrl, String details, Product product, Double price, User user, Seller seller) {
		super();
		this.id = id;
		this.imageUrl = imageUrl;
		this.price = price;
		this.details = details;
		this.product = product;
		this.user = user;
		this.seller = seller;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	public void setBiddingEndTime(LocalDateTime localDateTime) {
		// TODO Auto-generated method stub
		
	}

	public static void save(AuctionItem auctionItem) {
		// TODO Auto-generated method stub
		
	}

	public static Object findAll() {
		// TODO Auto-generated method stub
		return null;
	}

    // Constructors, Getters, Setters
}
