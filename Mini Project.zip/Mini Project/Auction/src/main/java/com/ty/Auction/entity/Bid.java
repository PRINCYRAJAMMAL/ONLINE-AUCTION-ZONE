package com.ty.Auction.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Bid {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String bidder;
    private double amount;
    private LocalDateTime timestamp;
    private String status;
	public Bid() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bid(Long id, String bidder, double amount, LocalDateTime timestamp, String status) {
		super();
		this.id = id;
		this.bidder = bidder;
		this.amount = amount;
		this.timestamp = timestamp;
		this.status = status;
	}
	@Override
	public String toString() {
		return "Bid [ bidder=" + bidder + ", amount=" + amount + ", timestamp=" + timestamp + ", status="
				+ status + "]";
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBidder() {
		return bidder;
	}
	public void setBidder(String bidder) {
		this.bidder = bidder;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	}

