package com.ty.Auction.Service;


import com.ty.Auction.entity.Product;

import com.ty.Auction.repository.ProductRepository;
import com.ty.Auction.repository.ProductRepository.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product getProductById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    @Override
    public void saveProduct(Product product) {
        productRepository.save(product);
    }

    
    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

	
	@Override
	public void updateProduct(Product product) {
        productRepository.save(product);

		// TODO Auto-generated method stub
		
	}

	@Override
	public Product findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	 public void deleteProduct(Long id) {
	        productRepository.deleteById(id);
	    }

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	 @Override
	    public void saveProduct1(Product product) {
	        productRepository.save(product);
	    }

	    
	    public List<Product> getAllProduct() {
	        return productRepository.findAll();
	    }

		@Override
		public Product getProduct() {
			// TODO Auto-generated method stub
			return null;
		}
	
}
