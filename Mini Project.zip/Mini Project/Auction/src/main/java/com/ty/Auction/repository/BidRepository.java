package com.ty.Auction.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.Auction.entity.Bid;

import java.util.List;
import java.util.Optional;

public interface BidRepository extends JpaRepository<Bid, Long> {
    Optional<Bid> findById(Long id);
    
}


